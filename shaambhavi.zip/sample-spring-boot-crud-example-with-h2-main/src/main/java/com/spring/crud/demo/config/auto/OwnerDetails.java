package com.spring.crud.demo.config.auto;

import lombok.Data;

@Data
public class OwnerDetails {
    private String name;
    private String email;
}
