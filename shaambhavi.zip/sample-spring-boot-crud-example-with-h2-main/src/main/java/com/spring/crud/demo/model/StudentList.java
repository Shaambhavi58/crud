package com.spring.crud.demo.model;

import java.util.ArrayList;
import java.util.List;

public class StudentList {
    public List<Student> items= new ArrayList<>();
}
